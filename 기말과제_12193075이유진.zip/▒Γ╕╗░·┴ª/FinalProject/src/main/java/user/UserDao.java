package user;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;


public class UserDao {

 private Connection conn;
 private PreparedStatement pstmt;
 private ResultSet rs;

 public UserDao() {
  try {
	  Class.forName("com.mysql.cj.jdbc.Driver");
	  conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/member_db?serverTimezone=UTC&useUnicode=true&characterEncoding=utf8","root", "mysql");

  } catch (Exception e) {
   e.printStackTrace();
  }
 }

 public int login(String userID, String userPassword) {
  String sqlStr = "SELECT userPassword FROM member_table WHERE userID=?";
  try {
   pstmt = conn.prepareStatement(sqlStr);
   pstmt.setString(1, userID);
   rs = pstmt.executeQuery();
   if(rs.next()) {
    if(rs.getString(1).equals(userPassword))
     return 1;  // 로그인 성공
    else
     return 0;  // 비밀번호 불일치
   }
   return -1;  // 아이디가 없음
   
  } catch(Exception e) {
   e.printStackTrace();
  }
  return -2; // 데이터 베이스 오류

 }
 
 public int join(User user) {
	 String sqlStr = "INSERT INTO member_table VALUES (?,?,?,?,?)";
	 try {
		 pstmt = conn.prepareStatement(sqlStr);
		 pstmt.setString(1, user.getUserID());
		 pstmt.setString(2, user.getUserPassword());
		 pstmt.setString(3, user.getUserName());
		 pstmt.setString(4, user.getAddress()); 
		 pstmt.setString(5, user.getPhoneNum());
		 return pstmt.executeUpdate();
	 }catch(Exception e) {
		 e.printStackTrace();
	 }
	 return -1;
 }

 public ArrayList<User> getList(){

		String sqlStr = "SELECT * FROM member_table";
		ArrayList<User> list = new ArrayList<User>();
		try {
			PreparedStatement pstmt = conn.prepareStatement(sqlStr);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				User user = new User();
				user.setUserID(rs.getString(1));
				user.setUserPassword(rs.getString(2));
				user.setUserName(rs.getString(3));
				user.setAddress(rs.getString(4));
				user.setPhoneNum(rs.getString(5));
				list.add(user);
			}
		}catch (Exception e) {
				e.printStackTrace();
			}
		return list; 
	}
 public int delete(String userID) {
	 String sqlStr = "Delete from member_table WHERE userID = ?";
	 try {
		 PreparedStatement pstmt = conn.prepareStatement(sqlStr);
		 pstmt.setString(1, userID);
		 return pstmt.executeUpdate();
	 } catch(Exception e) {
		 e.printStackTrace();
	 }
	 return -1;
 }
}