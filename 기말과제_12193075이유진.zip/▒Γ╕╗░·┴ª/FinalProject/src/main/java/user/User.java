package user;

public class User {
	
	private String userID;
	private String userPassword;
	private String userName;
	private String address;
	private String phoneNum;
	private String PasswordCheck;

	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPhoneNum() {
		return phoneNum;
	}
	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}
	
	public String getPasswordCheck() {
		return PasswordCheck;
	}
	public void setPasswordCheck(String passwordCheck) {
		PasswordCheck = passwordCheck;
	}
	
}
