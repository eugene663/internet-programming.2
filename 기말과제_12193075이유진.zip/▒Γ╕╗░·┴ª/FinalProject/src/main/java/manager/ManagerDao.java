package manager;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;


public class ManagerDao {

 private Connection conn;
 private PreparedStatement pstmt;
 private ResultSet rs;

 public ManagerDao() {
  try {
	  Class.forName("com.mysql.cj.jdbc.Driver");
	  conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/member_db?serverTimezone=UTC&useUnicode=true&characterEncoding=utf8","root", "mysql");

  } catch (Exception e) {
   e.printStackTrace();
  }
 }

 
 public int insert(Manager manager) {
	 String sqlStr = "INSERT INTO member_table VALUES (?,?)";
	 try {
		 pstmt = conn.prepareStatement(sqlStr);
		 pstmt.setString(1, manager.getManagerID());
		 pstmt.setString(2, manager.getManagerPassword());
		 return pstmt.executeUpdate();
	 }catch(Exception e) {
		 e.printStackTrace();
	 }
	 return -1;
 }

 public ArrayList<Manager> getList(){

		String sqlStr = "SELECT * FROM manager_table";
		ArrayList<Manager> list = new ArrayList<Manager>();
		try {
			PreparedStatement pstmt = conn.prepareStatement(sqlStr);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				Manager manager = new Manager();
				manager.setManagerID(rs.getString(1));
				manager.setManagerPassword(rs.getString(2));
				list.add(manager);
			}
		}catch (Exception e) {
				e.printStackTrace();
			}
		return list; 
	}
 public int delete(String managerID) {
	 String sqlStr = "Delete from manager_table WHERE managerID = ?";
	 try {
		 PreparedStatement pstmt = conn.prepareStatement(sqlStr);
		 pstmt.setString(1, managerID);
		 return pstmt.executeUpdate();
	 } catch(Exception e) {
		 e.printStackTrace();
	 }
	 return -1;
 }
 public int check(String userID) {
	  String sqlStr = "SELECT managerID FROM manager_table";
	  try {
	   pstmt = conn.prepareStatement(sqlStr);
	   rs = pstmt.executeQuery();
	   if(rs.next()) {
	    if(rs.getString(1).equals(userID))
	     return 1;  // 로그인 성공
	    else
	     return 0;  // 비밀번호 불일치
	   }
	   return -1;  // 아이디가 없음
	   
	  } catch(Exception e) {
	   e.printStackTrace();
	  }
	  return -2; // 데이터 베이스 오류

	 }
}