package product;

public class Product {
	private int productID;
	private String productName;
	private String stock;
	private String price;
	private String details;
	private String imgPath;
	private int productAvailable;

    public int getProductID() {
		return productID;
	}
	public void setProductID(int productID) {
		this.productID = productID;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getStock() {
		return stock;
	}
	public void setStock(String stock) {
		this.stock = stock;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getDetails() {
		return details;
	}
	public void setDetails(String details) {
		this.details = details;
	}
	public String getImgPath() {
		return imgPath;
	}
	public void setImgPath(String imgPath) {
		this.imgPath = imgPath;
	}
	public int getProductAvailable() {
		return productAvailable;
	}
	public void setProductAvailable(int productAvailable) {
		this.productAvailable = productAvailable;
	}
	
	
}
