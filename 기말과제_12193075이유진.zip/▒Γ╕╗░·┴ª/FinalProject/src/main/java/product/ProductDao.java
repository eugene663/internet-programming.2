package product;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;


public class ProductDao {

 private Connection conn;
 private ResultSet rs;

 public ProductDao() {
  try {
	  //Class.forName("com.mysql.cj.jdbc.Driver");
	  Class.forName("com.mysql.jdbc.Driver");
	  conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/member_db?serverTimezone=UTC&useUnicode=true&characterEncoding=utf8","root", "mysql");

  } catch (Exception e) {
   e.printStackTrace();
  }
 }
 
public int getNext() {
	String sqlStr = "SELECT productID FROM product_table ORDER BY productID DESC";
	try {
		PreparedStatement pstmt = conn.prepareStatement(sqlStr);
		rs = pstmt.executeQuery();
		if(rs.next()) {
			return rs.getInt(1) + 1;
		}
		return 1; //첫번째 게시물
	}catch (Exception e) {
			e.printStackTrace();
		}
	return -1; //데이터베이스 오류
}

public int insert(String productName, String price, String stock, String details, String imgPath) {
	String sqlStr = "INSERT INTO product_table VALUE (?, ?, ?, ?, ?, ?, ?)";
	try {
		PreparedStatement pstmt = conn.prepareStatement(sqlStr);
		pstmt.setInt(1, getNext());
		pstmt.setString(2, productName);
		pstmt.setInt(3, Integer.parseInt(price));
		pstmt.setInt(4, Integer.parseInt(stock));
		pstmt.setString(5, details);
		pstmt.setString(6, imgPath);
		pstmt.setInt(7, 1);
		return pstmt.executeUpdate();
	}catch (Exception e) {
			e.printStackTrace();
		}
	return -1; //데이터베이스 오류
}

public ArrayList<Product> getList(int mainPage){

	String sqlStr = "SELECT * FROM product_table WHERE productID < ? AND productAvailable = 1 ORDER BY productID DESC LIMIT 10";
	ArrayList<Product> list = new ArrayList<Product>();
	try {
		PreparedStatement pstmt = conn.prepareStatement(sqlStr);
		pstmt.setInt(1, getNext() - (mainPage - 1) * 10);
		rs = pstmt.executeQuery();
		while(rs.next()) {
			Product product = new Product();
			product.setProductID(rs.getInt(1));
			product.setProductName(rs.getString(2));
			product.setPrice(rs.getString(3));
			product.setStock(rs.getString(4));
			product.setDetails(rs.getString(5));
			product.setImgPath(rs.getString(6));
			product.setProductAvailable(rs.getInt(7));
			list.add(product);
		}
	}catch (Exception e) {
			e.printStackTrace();
		}
	return list; 
}
public boolean nextPage(int mainPage) {
	String sqlStr =  "SELECT * FROM product_table WHERE productID < ? AND productAvailable = 1";
	try {
		PreparedStatement pstmt = conn.prepareStatement(sqlStr);
		pstmt.setInt(1, getNext() - (mainPage - 1) * 10);
		rs = pstmt.executeQuery();
		if(rs.next()) {
			return true;
		}
	}catch (Exception e) {
			e.printStackTrace();
		}
	return false; 
}

public Product getProduct(int boardID) {
	String sqlStr = "SELECT * FROM product_table WHERE productID = ?";
	try {
		PreparedStatement pstmt = conn.prepareStatement(sqlStr);
		pstmt.setInt(1, boardID);
		rs = pstmt.executeQuery();
		while(rs.next()) {
			Product product = new Product();
			product.setProductID(rs.getInt(1));
			product.setProductName(rs.getString(2));
			product.setPrice(rs.getString(3));
			product.setStock(rs.getString(4));
			product.setDetails(rs.getString(5));
			product.setProductAvailable(rs.getInt(6));
			return product;
		}
	}catch (Exception e) {
			e.printStackTrace();
		}
	return null; 
}


}

