-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: localhost    Database: member_db
-- ------------------------------------------------------
-- Server version	5.7.34-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `product_table`
--

DROP TABLE IF EXISTS `product_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_table` (
  `productID` int(10) NOT NULL,
  `productName` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `price` int(7) DEFAULT NULL,
  `stock` int(5) DEFAULT NULL,
  `details` varchar(1000) COLLATE utf8_bin DEFAULT NULL,
  `imgPath` varchar(300) COLLATE utf8_bin DEFAULT NULL,
  `productAvailable` int(1) DEFAULT NULL,
  PRIMARY KEY (`productID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_table`
--

LOCK TABLES `product_table` WRITE;
/*!40000 ALTER TABLE `product_table` DISABLE KEYS */;
INSERT INTO `product_table` VALUES (1,'호박고구마 1kg',23000,33,'최적의 조건에서 재배한 호박고구마입니다. 최상급 호박고구마만을 엄선하여 판매합니다.','image/sweetpotato.jpg',1),(2,' 초고당도 수박',30000,43,'12브릭스 이상의 초고당도 수박만 판매하므로 직접 고를 필요가 없습니다. 달콤한 과즙을 즐겨보세요!','image/watermelon.png',1),(3,'양파 1망(8개)',9300,70,'양파는 자극적인 냄새와 매운맛이 강한데, 이것이 육류나 생선의 냄새를 없애줍니다. 삶거나 굽거나 튀기면 매운맛이 없어지고 단맛과 향기가 난다. 수프를 비롯하여 육류나 채소에 섞어 끓이는 요리에 사용되고, 카레라이스의 재료로서도 요긴하게 사용할 수 있습니다.','image/onion.png',1),(4,'감자 1kg',18000,28,'감자는 땅속의 사과로 불릴 만큼 비타민 C가 풍부합니다. 100g의 감자에는 26㎎의 비타민 C가 들어있어 하루 2개면 일일 권장 섭취량(50㎎)을 채울 수 있습니다. 게다가  가열 조리하더라도 96% 이상이 잔존해 비타민 C 파괴가 거의 없습니다.','image/potato.png',1),(5,'당근 5개',3900,180,'당근은 색이 예뻐서 여러 음식에 활용하기 좋습니다. 뿐만 아니라 암 예방, 눈 건강 유지, 숙변 제거, 다이어트 등 여러 효과가 있습니다.','image/carrot.png',1),(6,'복숭아 1kg',34000,65,'달콤한 향과 풍부한 과즙으로  더위에 떨어진 입맛을 살리는 여름 제철과일입니다. 피로 회복과 피부 관리에 뛰어난 효과를 보입니다.','image/peach.png',1);
/*!40000 ALTER TABLE `product_table` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-06-20 23:31:00
